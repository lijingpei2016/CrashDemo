//
//  DTHTMLElementTest.h
//  DTCoreText
//
//  Created by Hubert SARRET on 11/04/13.
//  Copyright (c) 2013 Drobnik.com. All rights reserved.
//

#import <DTCoreText/DTCoreText.h>
#import <XCTest/XCTest.h>

@interface DTHTMLElementTest : XCTestCase

@end
