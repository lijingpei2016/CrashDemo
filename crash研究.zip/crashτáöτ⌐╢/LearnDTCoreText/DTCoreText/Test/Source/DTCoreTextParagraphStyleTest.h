//
//  DTCoreTextParagraphStyleTest.h
//  DTCoreText
//
//  Created by Oliver Drobnik on 2/25/13.
//  Copyright (c) 2013 Drobnik.com. All rights reserved.
//

#import <DTCoreText/DTCoreText.h>
#import <XCTest/XCTest.h>

@interface DTCoreTextParagraphStyleTest : XCTestCase

@end
