//
//  DTHTMLAttributedStringBuilder.h
//  DTCoreText
//
//  Created by Oliver Drobnik on 21.01.12.
//  Copyright (c) 2012 Drobnik.com. All rights reserved.
//

#import <DTFoundation/DTHTMLParser.h>

@class DTHTMLElement;

/**
 The block that gets executed whenever an element is flushed to the output string
 */
typedef void(^DTHTMLAttributedStringBuilderWillFlushCallback)(DTHTMLElement *);

/**
 The block that gets executed whenever html tag parsing error
 */
typedef void(^DTHTMLAttributedStringBuilderParseErrorCallback)(NSAttributedString *attr, NSError *);


/**
 Class for building an `NSAttributedString` from an HTML document.
 */
@interface DTHTMLAttributedStringBuilder : NSObject <DTHTMLParserDelegate>

/**
 @name Creating an Attributed String Builder
 */

/**
 Initializes and returns a new `NSAttributedString` object from the HTML contained in the given object and base URL.
 
 Options can be:
 
 - DTMaxImageSize: the maximum CGSize that a text attachment can fill
 - DTDefaultFontFamily: the default font family to use instead of Times New Roman
 - DTDefaultFontName: the default font face to use instead of Times New Roman
 - DTDefaultFontSize: the default font size to use instead of 12
 - DTDefaultTextColor: the default text color
 - DTDefaultLinkColor: the default color for hyperlink text
 - DTDefaultLinkDecoration: the default decoration for hyperlinks
 - DTDefaultLinkHighlightColor: the color to show while the hyperlink is highlighted
 - DTDefaultTextAlignment: the default text alignment for paragraphs
 - DTDefaultLineHeightMultiplier: The multiplier for line heights
 - DTDefaultFirstLineHeadIndent: The default indent for left margin on first line
 - DTDefaultHeadIndent: The default indent for left margin except first line
 - DTDefaultListIndent: The amount by which lists are indented
 - DTDefaultStyleSheet: The default style sheet to use
 - DTUseiOS6Attributes: use iOS 6 attributes for building (UITextView compatible)
 - DTWillFlushBlockCallBack: a block to be executed whenever content is flushed to the output string
 - DTIgnoreInlineStylesOption: All inline style information is being ignored and only style blocks used
 
- DTMaxImageSize：文本附件可以填充的最大CGSize
- DTDefaultFontFamily：用于代替 Times New Roman 的默认字体系列
- DTDefaultFontName：使用默认字体而不是 Times New Roman
- DTDefaultFontSize：使用的默认字体大小而不是 12
- DTDefaultTextColor：默认文本颜色
- DTDefaultLinkColor：超链接文本的默认颜色
- DTDefaultLinkDecoration：超链接的默认装饰
- DTDefaultLinkHighlightColor：突出显示超链接时显示的颜色
- DTDefaultTextAlignment：段落的默认文本对齐方式
- DTDefaultLineHeightMultiplier：行高的乘数
- DTDefaultFirstLineHeadIndent：第一行左边距的默认缩进
- DTDefaultHeadIndent：除了第一行之外的左边距的默认缩进
- DTDefaultListIndent：列表缩进的数量
- DTDefaultStyleSheet：要使用的默认样式表
- DTUseiOS6Attributes：使用 iOS 6 属性进行构建（UITextView 兼容）
- DTWillFlushBlockCallBack：每当内容刷新到输出字符串时要执行的块
- DTIgnoreInlineStylesOption：忽略所有内联样式信息，仅使用样式块
 
 @param data The data in HTML format from which to create the attributed string.
 @param options Specifies how the document should be loaded. Contains values described in NSAttributedString(HTML).
 @param docAttributes Currently not in use.
 @returns Returns an initialized object, or `nil` if the data can’t be decoded.
 */
- (id)initWithHTML:(NSData *)data options:(NSDictionary *)options documentAttributes:(NSDictionary * __autoreleasing*)docAttributes;


/**
 @name Generating Attributed Strings
 */

/**
  Creates the attributed string when called the first time.
 @returns An `NSAttributedString` representing the HTML document passed in the initializer.
 */
- (NSAttributedString *)generatedAttributedString;


/**
 This block is called before the element is written to the output attributed string
 */
@property (nonatomic, copy) DTHTMLAttributedStringBuilderWillFlushCallback willFlushCallback;
/**
 The block that gets executed whenever html tag parsing error
 */
@property (nonatomic, copy) DTHTMLAttributedStringBuilderParseErrorCallback parseErrorCallback;

/**
 Setting this property to `YES` causes the tree of parse nodes to be preserved until the end of the generation process. This allows to output the HTML structure of the document for debugging.
 */
@property (nonatomic, assign) BOOL shouldKeepDocumentNodeTree;

/**
 This func can abort AttributedString building.
 */
- (void)abortParsing;

@end
