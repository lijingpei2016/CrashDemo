//
// AutoLayoutDemoViewController.h
// DTCoreText
//
// Created by David Whetstone on 5/8/15.
// Copyright (c) 2015 Drobnik.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AutoLayoutDemoViewController : UIViewController
@property (nonatomic, strong) id fileName;
@end