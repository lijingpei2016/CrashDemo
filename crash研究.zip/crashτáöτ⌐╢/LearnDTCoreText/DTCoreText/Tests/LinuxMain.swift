import XCTest

import DTCoreTextTests

var tests = [XCTestCaseEntry]()
tests += DTCoreTextTests.allTests()
XCTMain(tests)
