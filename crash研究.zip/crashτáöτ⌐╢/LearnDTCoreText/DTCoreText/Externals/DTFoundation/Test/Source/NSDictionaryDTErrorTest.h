//
//  NSDictionaryDTErrorTest.h
//  DTFoundation
//
//  Created by Stefan Gugarel on 10/18/12.
//  Copyright (c) 2012 Cocoanetics. All rights reserved.
//

#if !TARGET_OS_WATCH

#import <XCTest/XCTest.h>

@interface NSDictionaryDTErrorTest : XCTestCase

@end

#endif
