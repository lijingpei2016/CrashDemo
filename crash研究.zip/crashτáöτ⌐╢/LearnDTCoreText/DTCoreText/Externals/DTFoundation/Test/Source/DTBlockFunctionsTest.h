//
//  DTBlockFunctionsTest.h
//  DTFoundation
//
//  Created by Oliver Drobnik on 02.10.13.
//  Copyright (c) 2013 Cocoanetics. All rights reserved.
//

#if !TARGET_OS_WATCH

#import <XCTest/XCTest.h>

@interface DTBlockFunctionsTest : XCTestCase

@end

#endif
