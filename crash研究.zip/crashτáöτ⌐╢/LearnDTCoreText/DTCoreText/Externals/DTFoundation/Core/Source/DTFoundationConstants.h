//
//  DTFoundationConstants.h
//  DTFoundation
//
//  Created by Stefan Gugarel on 10/18/12.
//  Copyright (c) 2012 Cocoanetics. All rights reserved.
//

#import <Foundation/Foundation.h>


// string constant for NSError domain
extern NSString * const DTFoundationErrorDomain;
