//
//  MarkCrashVC.m
//  KScrashDemo
//
//  Created by 李境沛 on 2022/2/17.
//

#import "MarkCrashVC.h"

@interface MarkCrashVC ()

@end

@implementation MarkCrashVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self arrOut];
}


- (void)runUnrecognizedSelector {
    [self performSelector:@selector(unrecognizedSelectorXxxx)];
}

- (void)arrOut {
    NSArray *arr = [[NSArray alloc] init];
    id a = arr[1];
    NSLog(@"2");
}


@end
