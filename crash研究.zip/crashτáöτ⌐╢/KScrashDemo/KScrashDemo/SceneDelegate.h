//
//  SceneDelegate.h
//  KScrashDemo
//
//  Created by 李境沛 on 2021/12/30.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

