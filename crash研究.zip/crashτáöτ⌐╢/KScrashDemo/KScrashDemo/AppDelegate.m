//
//  AppDelegate.m
//  KScrashDemo
//
//  Created by 李境沛 on 2021/12/30.
//

#import "AppDelegate.h"
#import <KSCrash/KSCrash.h>
#import <KSCrash/KSCrashInstallation.h>
#import <KSCrash/KSCrashInstallationEmail.h>

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    KSCrashInstallation* installation = [self makeEmailInstallation];
    [installation install];
    
    // 发送所有的 crash 日志
    [installation sendAllReportsWithCompletion:^(NSArray* reports, BOOL completed, NSError* error) {
         if(completed) {
             NSLog(@"Sent %d reports", (int)[reports count]);
         } else {
             NSLog(@"Failed to send reports: %@", error);
         }
     }];
    
    return YES;
}

- (KSCrashInstallation*) makeEmailInstallation
{
    NSString* emailAddress = @"330732842@qq.com";
    
    KSCrashInstallationEmail* email = [KSCrashInstallationEmail sharedInstance];
    email.recipients = @[emailAddress];
    email.subject = @"Crash Report";
    email.message = @"This is a crash report";
    email.filenameFmt = @"crash-report-%d.txt.gz";
    [email setReportStyle:KSCrashEmailReportStyleApple useDefaultFilenameFormat:YES];

    return email;
}


@end
