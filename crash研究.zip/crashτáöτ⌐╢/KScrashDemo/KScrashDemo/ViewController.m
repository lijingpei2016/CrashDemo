//
//  ViewController.m
//  KScrashDemo
//
//  Created by 李境沛 on 2021/12/30.
//

#import "ViewController.h"
#import "JPFileHandel.h"
#import "MarkCrashVC.h"

@interface ViewController ()

@property (nonatomic, strong) NSMutableArray *arr;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.arr = [[NSMutableArray alloc] init];
    
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self present];
}


- (void)present {
    MarkCrashVC *vc = [[MarkCrashVC alloc] init];
    [self presentViewController:vc animated:YES completion:nil];
}


@end
