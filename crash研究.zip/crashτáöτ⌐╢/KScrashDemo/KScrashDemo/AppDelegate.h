//
//  AppDelegate.h
//  KScrashDemo
//
//  Created by 李境沛 on 2021/12/30.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

