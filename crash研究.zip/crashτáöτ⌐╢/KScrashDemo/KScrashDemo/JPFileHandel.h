//
//  JPFileHandel.h
//  KScrashDemo
//
//  Created by 李境沛 on 2022/1/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface JPFileHandel : NSObject

+ (void)addStringToFile:(NSString *)str;

@end

NS_ASSUME_NONNULL_END
