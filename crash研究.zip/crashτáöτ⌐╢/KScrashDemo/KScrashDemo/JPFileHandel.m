//
//  JPFileHandel.m
//  KScrashDemo
//
//  Created by 李境沛 on 2022/1/21.
//

#import "JPFileHandel.h"

@implementation JPFileHandel

+ (void)addStringToFile:(NSString *)str {

    NSString *s = str.copy;
    
    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    NSString *filePath = [documentPath stringByAppendingPathComponent:@"test.txt"];
    
    NSString *oldStr = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:NULL];
    
    if (oldStr.length >0) {
        s = [NSString stringWithFormat:@"%@\n%@",oldStr,s];
    }
    
    NSError *error;
    [s writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:&error];
    if (error) {
       NSLog(@"文件写入失败!");
    }else{
       NSLog(@"文件写入成功!");
    }
    
}

@end
